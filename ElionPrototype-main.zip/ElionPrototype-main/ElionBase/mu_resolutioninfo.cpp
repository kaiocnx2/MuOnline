#include "stdafx.h"
#include "mu_resolutioninfo.h"

const mu_text *g_FontPath[MAX_FONT] =
{
	_T("./data/fonts/dejavusans.ttf"),
	_T("./data/fonts/dejavusans-bold.ttf"),
	_T("./data/fonts/dejavusans.ttf"),
	_T("./data/fonts/dejavusans-bold.ttf"),
};