#ifndef __MU_DIRECTX_GLOBAL_H__
#define __MU_DIRECTX_GLOBAL_H__

#pragma once

namespace EDirectX
{
	extern mu_uint32 CurrentCommandBufferIndex;
};

#endif