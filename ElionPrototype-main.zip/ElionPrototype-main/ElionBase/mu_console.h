#ifndef __MU_CONSOLE_H__
#define __MU_CONSOLE_H__

#pragma once

void RedirectIOToConsole();

#endif
