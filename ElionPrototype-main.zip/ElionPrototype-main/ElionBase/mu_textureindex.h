#ifndef __MU_TEXTURE_INDEX_H__
#define __MU_TEXTURE_INDEX_H__

#pragma once

//#define USE_TEXTURE_NAME_CACHE

enum TEXTURE : mu_uint32
{
	INVALID_TEXTURE = 0xFFFFFFFF,
};

#endif